# 🔐 Enforce MFA via Conditional Access in Microsoft Entra ID

## 📘 Project Overview

This project demonstrates how to enforce Multi-Factor Authentication (MFA) for selected users using Conditional Access policies in Microsoft Entra ID.

## 📸 Project Screenshots

### 1. Users Created
![Users](./screenshots/1_users_created.png)

### 2. Group Assignment (Optional)
![Group](./screenshots/2_group_assignment.png)

### 3. Conditional Access Policy Overview
![Policy Overview](./screenshots/3_policy_overview.png)

### 4. Conditions Setup (Risk, Location, Platforms)
![Conditions](./screenshots/4_conditions_setup.png)

### 5. MFA Prompt via Microsoft Authenticator
![MFA Prompt](./screenshots/5_mfa_prompt.png)

### 6. Entra Sign-In Logs Showing Policy Enforcement
![Sign-In Logs](./screenshots/6_signin_logs.png)

### 7. Trusted Location Config (Optional)
![Trusted Locations](./screenshots/7_trusted_locations.png)