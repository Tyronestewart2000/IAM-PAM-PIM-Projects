# Project Notes

- Created test users: `secureuser`, `standarduser`
- Added users to a group for scoped policy
- Conditional Access enforced based on:
  - Medium user risk
  - Medium sign-in risk
  - Trusted locations and networks
  - Device platforms: Android, Microsoft, Windows
- Used tools: Microsoft Entra ID, Azure Portal, Microsoft Authenticator, Audit Logs